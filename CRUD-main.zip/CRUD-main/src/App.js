import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Rotas from './Rotas/Rotas'

function App() {
  return (
    <div>
      <Rotas />
    </div>
  );
}

export default App;



// import './App.css';
// import Rotas from './components/Rotas';
// import 'bootstrap/dist/css/bootstrap.min.css';

// function App() {
//   return (
//     <div>
//       <Rotas/>
//     </div>
//   );
// }

// export default App;
